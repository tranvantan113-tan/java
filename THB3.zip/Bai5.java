/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package THB3;

import java.util.Random;

/**
 *
 * @author My PC
 */
public class Bai5 {
    public static void main(String[] args) {
        int n = 10;
        int[][] matrix1 = new int[n][n];
        int[][] matrix2 = new int[n][n];

        // a. Sinh ngẫu nhiên 2 mảng 2 chiều và in chúng dưới dạng ma trận
        generateRandomMatrix(matrix1, n);
        generateRandomMatrix(matrix2, n);
        System.out.println("a. Mảng 1:");
        printMatrix(matrix1);
        System.out.println("   Mảng 2:");
        printMatrix(matrix2);

        // b. Cộng hai ma trận
        int[][] sumMatrix = addMatrices(matrix1, matrix2, n);
        System.out.println("b. Tổng của hai ma trận:");
        printMatrix(sumMatrix);

        // c. Nhân hai ma trận
        int[][] productMatrix = multiplyMatrices(matrix1, matrix2, n);
        System.out.println("c. Tích của hai ma trận:");
        printMatrix(productMatrix);
    }

    // Thêm các phương thức dưới đây để thực hiện các yêu cầu bài tập.

    // Phương thức sinh ngẫu nhiên mảng 2 chiều
    public static void generateRandomMatrix(int[][] matrix, int n) {
        Random rand = new Random();
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                matrix[i][j] = rand.nextInt(201) - 100; // Sinh ngẫu nhiên từ -100 đến 100
            }
        }
    }

    // Phương thức in mảng 2 chiều dưới dạng ma trận
    public static void printMatrix(int[][] matrix) {
        for (int[] row : matrix) {
            for (int num : row) {
                System.out.printf("%5d", num);
            }
            System.out.println();
        }
    }

    // Phương thức cộng hai ma trận
    public static int[][] addMatrices(int[][] matrix1, int[][] matrix2, int n) {
        int[][] sumMatrix = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                sumMatrix[i][j] = matrix1[i][j] + matrix2[i][j];
            }
        }
        return sumMatrix;
    }

    // Phương thức nhân hai ma trận
    public static int[][] multiplyMatrices(int[][] matrix1, int[][] matrix2, int n) {
        int[][] productMatrix = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                productMatrix[i][j] = 0;
                for (int k = 0; k < n; k++) {
                    productMatrix[i][j] += matrix1[i][k] * matrix2[k][j];
                }
            }
        }
        return productMatrix;
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package THB3;

import java.util.Scanner;

/**
 *
 * @author My PC
 */
public class Bai1 {
  public static String toBinary(int n) {
    StringBuilder binary = new StringBuilder();
    while (n != 0) {
      binary.append(n % 2);
      n /= 2;
    }
    return binary.reverse().toString();
  }

  public static String toHexadecimal(int n) {
    StringBuilder hexadecimal = new StringBuilder();
    while (n != 0) {
        int digit = n % 16;
        if (digit < 10) {
            hexadecimal.append(digit);
        } else {
            hexadecimal.append((char) ('a' + digit - 10));
        }
        n /= 16;
    }
    return hexadecimal.reverse().toString();
  }

  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);

    // Nhập số nguyên dương
    System.out.print("Nhập số nguyên dương: ");
    int n = input.nextInt();

    // Chuyển đổi sang hệ nhị phân
    String binary = toBinary(n);
    System.out.println("Số nhị phân là: " + binary);

    // Chuyển đổi sang hệ thập lục phân
    String hexadecimal = toHexadecimal(n);
    System.out.println("Số thập lục phân là: " + hexadecimal);
  }
}

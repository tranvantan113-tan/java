/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package THB3;

import java.util.Arrays;

/**
 *
 * @author My PC
 */
public class Bai2 {
    public static void main(String[] args) {
     int[] a = {1, 10, 5, 7, -12, 17, 21, 1, -7, 1, 8, 9, 17, 13};
        
        // a. Đếm số số dương, số âm, số không trong mảng
        int positiveCount = 0;
        int negativeCount = 0;
        int zeroCount = 0;
        for (int num : a) {
            if (num > 0) {
                positiveCount++;
            } else if (num < 0) {
                negativeCount++;
            } else {
                zeroCount++;
            }
        }
        System.out.println("a. Số dương: \u00F4" + positiveCount);
        System.out.println("   Số âm: \u00F4" + negativeCount);
        System.out.println("   Số không: \u00F4" + zeroCount);

        // b. Tính tổng các số trong mảng
        int sum = 0;
        for (int num : a) {
            sum += num;
        }
        System.out.println("b. Tổng các số trong mảng: \u00F4" + sum);

        // c. Tính tổng các số chẵn trong mảng
        int evenSum = 0;
        for (int num : a) {
            if (num % 2 == 0) {
                evenSum += num;
            }
        }
        System.out.println("c. Tổng các số chẵn trong mảng: \u00F4" + evenSum);

        // d. Tính tổng các số lẻ trong mảng
        int oddSum = 0;
        for (int num : a) {
            if (num % 2 != 0) {
                oddSum += num;
            }
        }
        System.out.println("d. Tổng các số lẻ trong mảng: \u00F4" + oddSum);

        // e. Tính trung bình cộng các số dương, trung bình cộng các số âm
        int positiveTotal = 0;
        int negativeTotal = 0;
        for (int num : a) {
            if (num > 0) {
                positiveTotal += num;
            } else if (num < 0) {
                negativeTotal += num;
            }
        }
        double positiveAverage = positiveCount > 0 ? (double) positiveTotal / positiveCount : 0;
        double negativeAverage = negativeCount > 0 ? (double) negativeTotal / negativeCount : 0;
        System.out.println("e. Trung bình cộng các số dương: \u00F4" + positiveAverage);
        System.out.println("   Trung bình cộng các số âm: \u00F4" + negativeAverage);

        // f. Đổi các số trong mảng thành căn bậc 2 của số đó, đổi các số âm thành bình phương của nó
        for (int i = 0; i < a.length; i++) {
            if (a[i] > 0) {
                a[i] = (int) Math.sqrt(a[i]);
            } else if (a[i] < 0) {
                a[i] = a[i] * a[i];
            }
        }

        // g. Tìm số lớn nhất và số nhỏ nhất trong mảng
        int max = a[0];
        int min = a[0];
        for (int num : a) {
            if (num > max) {
                max = num;
            }
            if (num < min) {
                min = num;
            }
        }
        System.out.println("g. Số lớn nhất trong mảng: \u00F4" + max);
        System.out.println("   Số nhỏ nhất trong mảng: \u00F4" + min);

        // h. Số dương bé nhất, số âm lớn nhất trong mảng
        int smallestPositive = Integer.MAX_VALUE;
        int largestNegative = Integer.MIN_VALUE;
        for (int num : a) {
            if (num > 0 && num < smallestPositive) {
                smallestPositive = num;
            }
            if (num < 0 && num > largestNegative) {
                largestNegative = num;
            }
        }
        System.out.println("h. Số dương bé nhất trong mảng: \u00F4" + (smallestPositive != Integer.MAX_VALUE ? smallestPositive : "Không có số dương"));
        System.out.println("   Số âm lớn nhất trong mảng: \u00F4" + (largestNegative != Integer.MIN_VALUE ? largestNegative : "Không có số âm"));

        // i. Tìm xem có bao nguyên số nguyên x xuất hiện trong mảng và in các vị trí xuất hiện x, với x = 1.
        int x = 1;
        System.out.print("i. Số nguyên \u00F4" + x + " xuất hiện tại vị trí: ");
        boolean found = false;
        for (int i = 0; i < a.length; i++) {
            if (a[i] == x) {
                System.out.print(i + " ");
                found = true;
            }
        }
        if (!found) {
            System.out.print("Không có \u00F4");
        }
        System.out.println();

        // j. Vị trí đầu tiên trong mảng mang giá trị lẻ, vị trí cuối cùng trong mảng mang giá trị chẵn
        int firstOddIndex = -1;
        int lastEvenIndex = -1;
        for (int i = 0; i < a.length; i++) {
            if (a[i] % 2 != 0 && firstOddIndex == -1) {
                firstOddIndex = i;
            }
            if (a[i] % 2 == 0) {
                lastEvenIndex = i;
            }
        }
        System.out.println("j. Vị trí đầu tiên giá trị lẻ: \u00F4" + firstOddIndex);
        System.out.println("   Vị trí cuối cùng giá trị chẵn: \u00F4" + lastEvenIndex);

        // k. Sắp xếp để thu được mảng tăng dần
        Arrays.sort(a);

        // l. Sắp xếp để thu được mảng dãy giảm dần
        for (int i = 0; i < a.length / 2; i++) {
            int temp = a[i];
            a[i] = a[a.length - i - 1];
            a[a.length - i - 1] = temp;
        }
    }
}

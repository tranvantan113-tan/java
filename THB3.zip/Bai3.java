/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package THB3;

/**
 *
 * @author My PC
 */
import java.util.Arrays;

public class Bai3 {
    public static void main(String[] args) {
        int n = 50;
        int[] arr = new int[n];

        // a. Sinh ngẫu nhiên giá trị từ 0 đến 500 và in mảng lên màn hình
        for (int i = 0; i < n; i++) {
            arr[i] = (int) (Math.random() * 501); // Sinh ngẫu nhiên từ 0 đến 500
        }
        System.out.println("a. Mảng ngẫu nhiên:");
        System.out.println(Arrays.toString(arr));

        // b. Thống kê số lượng số chẵn, số lẻ, trung bình cộng
        int evenCount = 0;
        int oddCount = 0;
        int evenSum = 0;
        int oddSum = 0;
        for (int num : arr) {
            if (num % 2 == 0) {
                evenCount++;
                evenSum += num;
            } else {
                oddCount++;
                oddSum += num;
            }
        }
        double evenAverage = evenCount > 0 ? (double) evenSum / evenCount : 0;
        double oddAverage = oddCount > 0 ? (double) oddSum / oddCount : 0;
        System.out.println("b. Số lượng số chẵn: " + evenCount);
        System.out.println("   Số lượng số lẻ: " + oddCount);
        System.out.println("   Trung bình cộng số chẵn: " + evenAverage);
        System.out.println("   Trung bình cộng số lẻ: " + oddAverage);

        // c. Tìm số lớn thứ 2 và số bé thứ 2 trong mảng
        Arrays.sort(arr); // Sắp xếp mảng theo thứ tự tăng dần
        int secondLargest = arr[n - 2];
        int secondSmallest = arr[1];
        System.out.println("c. Số lớn thứ 2: " + secondLargest);
        System.out.println("   Số bé thứ 2: " + secondSmallest);

        // d. Tìm số chẵn đầu tiên và số lẻ cuối cùng trong mảng, đổi vị trí của hai số này
        int firstEven = -1;
        int lastOdd = -1;
        for (int i = 0; i < n; i++) {
            if (arr[i] % 2 == 0 && firstEven == -1) {
                firstEven = i;
            }
            if (arr[i] % 2 != 0) {
                lastOdd = i;
            }
        }
        if (firstEven != -1 && lastOdd != -1) {
            int temp = arr[firstEven];
            arr[firstEven] = arr[lastOdd];
            arr[lastOdd] = temp;
        }
        System.out.println("d. Mảng sau khi đổi vị trí số chẵn đầu tiên và số lẻ cuối cùng:");
        System.out.println(Arrays.toString(arr));

        // e. Điểm số lượng số nguyên tố trong mảng và in ra các số nguyên tố
        System.out.print("e. Các số nguyên tố trong mảng: ");
        int primeCount = 0;
        for (int num : arr) {
            if (isPrime(num)) {
                System.out.print(num + " ");
                primeCount++;
            }
        }
        System.out.println("\n   Số lượng số nguyên tố: " + primeCount);

        // f. Kiểm tra mảng có tăng dần hay giảm dần
        boolean isIncreasing = isIncreasing(arr);
        boolean isDecreasing = isDecreasing(arr);
        System.out.println("f. Mảng có tăng dần: " + isIncreasing);
        System.out.println("   Mảng có giảm dần: " + isDecreasing);

        // g. Sắp xếp để thu được mảng tăng dần
        Arrays.sort(arr);
        System.out.println("g. Mảng tăng dần:");
        System.out.println(Arrays.toString(arr));

        // h. Sắp xếp để thu được mảng dãy giảm dần
        Arrays.sort(arr);
        for (int i = 0; i < n / 2; i++) {
            int temp = arr[i];
            arr[i] = arr[n - i - 1];
            arr[n - i - 1] = temp;
        }
    }
    // Phương thức kiểm tra số nguyên tố
public static boolean isPrime(int number) {
    if (number <= 1) {
        return false;
    }
    for (int i = 2; i <= Math.sqrt(number); i++) {
        if (number % i == 0) {
            return false;
        }
    }
    return true;
}

// Phương thức kiểm tra mảng có tăng dần
public static boolean isIncreasing(int[] arr) {
    for (int i = 1; i < arr.length; i++) {
        if (arr[i] < arr[i - 1]) {
            return false;
        }
    }
    return true;
}

// Phương thức kiểm tra mảng có giảm dần
public static boolean isDecreasing(int[] arr) {
    for (int i = 1; i < arr.length; i++) {
        if (arr[i] > arr[i - 1]) {
            return false;
        }
    }
    return true;
}
}

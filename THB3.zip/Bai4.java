/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package THB3;

import java.util.Random;

/**
 *
 * @author My PC
 */
public class Bai4 {
    public static void main(String[] args) {
        int n = 10;
        int[][] matrix = new int[n][n];

        // a. Sinh ngẫu nhiên mảng 2 chiều và in mảng dưới dạng ma trận
        generateRandomMatrix(matrix, n);
        printMatrix(matrix);

        // b. Tính tổng các phần tử trên mỗi hàng của ma trận
        int[] rowSums = sumRows(matrix, n);
        System.out.println("b. Tổng các phần tử trên mỗi hàng của ma trận:");
        printArray(rowSums);

        // c. Tính tổng các phần tử trên đường chéo chính và đường chéo phụ
        int mainDiagonalSum = sumMainDiagonal(matrix, n);
        int secondaryDiagonalSum = sumSecondaryDiagonal(matrix, n);
        System.out.println("c. Tổng đường chéo chính: " + mainDiagonalSum);
        System.out.println("   Tổng đường chéo phụ: " + secondaryDiagonalSum);

        // d. Tính tổng các số chẵn và số lẻ trên mỗi dòng
        int[] evenRowSums = sumEvenRows(matrix, n);
        int[] oddRowSums = sumOddRows(matrix, n);
        System.out.println("d. Tổng các số chẵn trên mỗi dòng:");
        printArray(evenRowSums);
        System.out.println("   Tổng các số lẻ trên mỗi dòng:");
        printArray(oddRowSums);

        // e. Tìm dòng có căn bậc 2 của tổng giá trị dòng là nhỏ nhất
        int minSqrtRow = findMinSqrtRow(rowSums, n);
        System.out.println("e. Dòng có căn bậc 2 của tổng giá trị dòng nhỏ nhất: Dòng " + minSqrtRow);

        // f. In ra ma trận chuyển vị của mảng 2 chiều
        int[][] transposedMatrix = transposeMatrix(matrix, n);
        System.out.println("f. Ma trận chuyển vị:");
        printMatrix(transposedMatrix);

        // g. Thay thế các giá trị trong mảng thành bình phương của nó
        squareMatrix(matrix, n);
        System.out.println("g. Ma trận sau khi bình phương các giá trị:");
        printMatrix(matrix);

        // h. Viết chương trình tính định thức của ma trận
        int determinant = calculateDeterminant(matrix, n);
        System.out.println("h. Định thức của ma trận: " + determinant);
    }

    // Thêm các phương thức dưới đây để thực hiện các yêu cầu bài tập.

    // Phương thức sinh ngẫu nhiên mảng 2 chiều
    public static void generateRandomMatrix(int[][] matrix, int n) {
        Random rand = new Random();
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                matrix[i][j] = rand.nextInt(201) - 100; // Sinh ngẫu nhiên từ -100 đến 100
            }
        }
    }

    // Phương thức in mảng 2 chiều dưới dạng ma trận
    public static void printMatrix(int[][] matrix) {
        for (int[] row : matrix) {
            for (int num : row) {
                System.out.printf("%5d", num);
            }
            System.out.println();
        }
    }

    // Phương thức tính tổng các phần tử trên mỗi hàng của ma trận
    public static int[] sumRows(int[][] matrix, int n) {
        int[] rowSums = new int[n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                rowSums[i] += matrix[i][j];
            }
        }
        return rowSums;
    }

    // Phương thức tính tổng các phần tử trên đường chéo chính
    public static int sumMainDiagonal(int[][] matrix, int n) {
        int sum = 0;
        for (int i = 0; i < n; i++) {
            sum += matrix[i][i];
        }
        return sum;
    }

    // Phương thức tính tổng các phần tử trên đường chéo phụ
    public static int sumSecondaryDiagonal(int[][] matrix, int n) {
        int sum = 0;
        for (int i = 0; i < n; i++) {
            sum += matrix[i][n - i - 1];
        }
        return sum;
    }

    // Phương thức tính tổng các số chẵn trên mỗi dòng
    public static int[] sumEvenRows(int[][] matrix, int n) {
        int[] evenRowSums = new int[n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (matrix[i][j] % 2 == 0) {
                    evenRowSums[i] += matrix[i][j];
                }
            }
        }
        return evenRowSums;
    }

    // Phương thức tính tổng các số lẻ trên mỗi dòng
    public static int[] sumOddRows(int[][] matrix, int n) {
        int[] oddRowSums = new int[n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (matrix[i][j] % 2 != 0) {
                    oddRowSums[i] += matrix[i][j];
                }
            }
        }
        return oddRowSums;
    }

    // Phương thức tìm dòng có căn bậc 2 của tổng giá trị dòng là nhỏ nhất
    public static int findMinSqrtRow(int[] rowSums, int n) {
        int minRow = 0;
        double minSqrt = Math.sqrt(rowSums[0]);
        for (int i = 1; i < n; i++) {
            double sqrt = Math.sqrt(rowSums[i]);
            if (sqrt < minSqrt) {
                minRow = i;
                minSqrt = sqrt;
            }
        }
        return minRow;
    }

    // Phương thức in mảng 1 chiều
    public static void printArray(int[] arr) {
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }

    // Phương thức in ma trận chuyển vị của mảng 2 chiều
    public static int[][] transposeMatrix(int[][] matrix, int n) {
        int[][] transposedMatrix = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                transposedMatrix[i][j] = matrix[j][i];
            }
        }
        return transposedMatrix;
    }

    // Phương thức thay thế các giá trị trong mảng thành bình phương của nó
    public static void squareMatrix(int[][] matrix, int n) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                matrix[i][j] *= matrix[i][j];
            }
        }
    }

    // Phương thức tính định thức của ma trận
    public static int calculateDeterminant(int[][] matrix, int n) {
        if (n == 1) {
            return matrix[0][0];
        }
        if (n == 2) {
            return matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0];
        }
        int determinant = 0;
        for (int i = 0; i < n; i++) {
            determinant += matrix[0][i] * calculateDeterminant(getSubMatrix(matrix, n, i), n - 1) * (i % 2 == 0 ? 1 : -1);
        }
        return determinant;
    }

    // Phương thức lấy ma trận con bằng cách loại bỏ dòng và cột xác định
    public static int[][] getSubMatrix(int[][] matrix, int n, int column) {
        int[][] subMatrix = new int[n - 1][n - 1];
        for (int i = 1; i < n; i++) {
            for (int j = 0, k = 0; j < n; j++) {
                if (j != column) {
                    subMatrix[i - 1][k] = matrix[i][j];
                    k++;
                }
            }
        }
        return subMatrix;
    }
}

